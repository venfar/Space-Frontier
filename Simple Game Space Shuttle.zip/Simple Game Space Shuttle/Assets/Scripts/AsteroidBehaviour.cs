using UnityEngine;

public class AsteroidBehaviour : MonoBehaviour
{

    public float FlySpeed;
    
    public enum Direction
    {
        Left = -2,
        Right = 2
    };
    public Direction FlyDirection;

    [Space(10)]
    [SerializeField] private float LifeTime;
    [SerializeField] private Vector3 MoveVector;

    private Rigidbody2D rb;


    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();

        MoveVector = ((transform.right / (int)FlyDirection ) + Vector3.down).normalized;
        rb.velocity = MoveVector * FlySpeed;


        rb.angularVelocity = 30;

        Destroy(gameObject, LifeTime);
    }


}
