using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using TMPro;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{

    public bool isGameStarted;
    public bool isPause;
    public float Score;

    [SerializeField] private float BestScore;    
    
    [SerializeField] private GameObject Game;
    [SerializeField] private GameObject GameHUD;
    [SerializeField] private GameObject MenuScreen;
    [SerializeField] private GameObject SettingsScreen;
    [SerializeField] private GameObject PauseWindow;


    [Space]
    [SerializeField] private TMP_Text BestScoreText;
    [SerializeField] private TMP_Text LastScoreText;
    [SerializeField] private TMP_Text ScoreGameText;
    

    [SerializeField] private TMP_Text MusicVolumeText;
    [SerializeField] private Slider MusicVolumeSlider;


    [Space(10)]
    [SerializeField] private AsteroidSpawnerScript AsteroidSpawnerScript;
    [SerializeField] private ShipBehaviour ShipBehaviour;
    [SerializeField] private Transform ObjectsPool;
    [SerializeField] private AudioSource AudioSource;



    // Start is called before the first frame update
    void Start()
    {
        Game.SetActive(false);
        GameHUD.SetActive(false);
        MenuScreen.SetActive(true);

        SettingsScreen.SetActive(false);

        OnChangedSliderVolume();
    }

    // Update is called once per frame
    void Update()
    {
        ScoreGameText.text = $"����: {Score}";


        if (BestScore > 0)
        {
            BestScoreText.text = $"������ ���� � ����: {BestScore}";
        }

        if(Score > 0)
        {
            LastScoreText.text = $"�� �������: {Score}";
        }
        else
        {
            LastScoreText.text = "";
        }
    }


    public void OnDeath()
    {
        isGameStarted = false;

        Game.SetActive(false);
        GameHUD.SetActive(false);
        MenuScreen.SetActive(true);


        if (Score > BestScore)
        {
            BestScore = Score;
        }

        for (int i = 0; i < ObjectsPool.childCount; i++)
        {
            Destroy(ObjectsPool.GetChild(i).gameObject);
        }
    }



    public void PlayGameButton()
    {
        isGameStarted = true;
        ShipBehaviour.gameObject.SetActive(true);
        ShipBehaviour.transform.position = new Vector2(0f, -1.1f);        
        Score = 0;

        Game.SetActive(true);
        GameHUD.SetActive(true);
        MenuScreen.SetActive(false);

        AsteroidSpawnerScript.OnStart();
    }

    public void SettingsButton()
    {
        SettingsScreen.SetActive(true);
    }
    public void CloseSettingsScreen()
    {
        SettingsScreen.SetActive(false);
    }

    public void OnChangedSliderVolume()
    {       
        AudioSource.volume = MusicVolumeSlider.value;

        MusicVolumeText.text = $"��������� ������: {Mathf.Round(AudioSource.volume * 100)}%";
    }

    public void PauseGameButton()
    {
        isPause = !isPause;
        Time.timeScale = isPause? 0 : 1;

        PauseWindow.SetActive(true);

        EventSystem.current.SetSelectedGameObject(null);
    }

    public void ResumeGameButton()
    {
        isPause = false;
        Time.timeScale = 1;

        PauseWindow.SetActive(false);
    }

    public void ExitGameButton()
    {
        Application.Quit();
    }

}
