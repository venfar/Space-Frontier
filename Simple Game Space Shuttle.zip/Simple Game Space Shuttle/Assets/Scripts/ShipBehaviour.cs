using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShipBehaviour : MonoBehaviour
{
    public GameManager GameManager;

    [Space(10)]
    [SerializeField] private float MovingSpeed;

    [SerializeField] private Transform ShipGun;


    [Space]
    [SerializeField] private AudioClip ShotSound;
    [SerializeField] private BulletBehaviour BulletPrefab;
    [SerializeField] private Transform ObjectsPool;


    private Rigidbody2D rb;
    private AudioSource audioSource;


    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();

        audioSource = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        if (!GameManager.isPause)
        {
            if (Input.GetKeyDown(KeyCode.Space))
            {
                Shoot();
            }
        }
    }


    private void FixedUpdate()
    {
        if (Input.GetKey(KeyCode.W))
        {
            rb.velocity += Vector2.up * MovingSpeed;
        }
        else if (Input.GetKey(KeyCode.S))
        {
            rb.velocity += Vector2.down * MovingSpeed;
        }

        if (Input.GetKey(KeyCode.A))
        {
            rb.velocity += Vector2.left * MovingSpeed;
        }
        else if (Input.GetKey(KeyCode.D))
        {
            rb.velocity += Vector2.right * MovingSpeed;
        }


    }

    private void Shoot()
    {
        BulletBehaviour bullet = Instantiate(BulletPrefab, ObjectsPool);

        bullet.transform.position = ShipGun.position;
        bullet.GameManager = GameManager;

        audioSource.PlayOneShot(ShotSound);
    }


    private void OnTriggerEnter2D(Collider2D col)
    {
        if (col.tag == "Asteroid")
        {
            GameManager.OnDeath();

            gameObject.SetActive(false);
        }
    }

}
