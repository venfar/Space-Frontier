using UnityEngine;

public class BulletBehaviour : MonoBehaviour
{
    public GameManager GameManager;

    [SerializeField] private float FlySpeed;
    [SerializeField] private float LifeTime;


    private Rigidbody2D rb;


    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();

        rb.velocity += Vector2.up * FlySpeed;

        Destroy(gameObject, LifeTime);
    }

    

    private void OnTriggerEnter2D(Collider2D col)
    {
        if(col.tag == "Asteroid")
        {
            GameManager.Score += 10;
            Destroy(col.gameObject);
            Destroy(this.gameObject);
        }

        
    }

    
}
